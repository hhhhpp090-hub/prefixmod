package com.example.prefixmod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.common.MinecraftForge;

@Mod(PrefixMod.MODID)
public class PrefixMod {
    public static final String MODID = "prefixmod";

    public PrefixMod() {
        MinecraftForge.EVENT_BUS.register(new PrefixHandler());
    }

    @SubscribeEvent
    public void setup(FMLCommonSetupEvent event) {
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        PrefixCommand.register(event.getDispatcher());
    }
}
