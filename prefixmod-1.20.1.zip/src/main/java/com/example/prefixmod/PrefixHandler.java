package com.example.prefixmod;

import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

public class PrefixHandler {
    public static void setPrefix(ServerPlayer player, String prefix) {
        player.getPersistentData().putString("prefixmod_prefix", prefix);
        applyPrefix(player);
    }

    public static void applyPrefix(ServerPlayer player) {
        Scoreboard scoreboard = player.getServer().getScoreboard();
        String teamName = "prefix_" + player.getStringUUID().substring(0, 8);

        PlayerTeam oldTeam = scoreboard.getPlayerTeam(teamName);
        if (oldTeam != null) scoreboard.removePlayerTeam(oldTeam);

        PlayerTeam team = scoreboard.addPlayerTeam(teamName);

        String prefix = player.getPersistentData().getString("prefixmod_prefix");
        if (prefix != null && !prefix.isEmpty()) {
            team.setPlayerPrefix(net.minecraft.network.chat.Component.literal(prefix));
        }

        scoreboard.addPlayerToTeam(player.getScoreboardName(), team);
    }

    @SubscribeEvent
    public void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            if (player.getPersistentData().contains("prefixmod_prefix")) {
                applyPrefix(player);
            }
        }
    }

    @SubscribeEvent
    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            if (player.getPersistentData().contains("prefixmod_prefix")) {
                applyPrefix(player);
            }
        }
    }
}
