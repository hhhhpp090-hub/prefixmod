package com.example.prefixmod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

public class PrefixCommand {
    private static final Map<String, String> PRESETS = new HashMap<>();
    static {
        PRESETS.put("Admin", "§4[Admin]§r ");
        PRESETS.put("Ukraine", "§9[Ukraine]§r ");
        PRESETS.put("Russia", "§1[Russia]§r ");
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("prefix")
            .then(Commands.literal("preset")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("preset", StringArgumentType.word())
                        .suggests((ctx, sb) -> {
                            PRESETS.keySet().forEach(sb::suggest);
                            return sb.buildFuture();
                        })
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            String preset = StringArgumentType.getString(ctx, "preset");
                            String value = PRESETS.get(preset);
                            if (value == null) {
                                ctx.getSource().sendFailure(Component.literal("Нет такого пресета: " + preset));
                                return 0;
                            }
                            PrefixHandler.setPrefix(target, value);
                            ctx.getSource().sendSuccess(Component.literal("Префикс установлен: " + preset), true);
                            return 1;
                        })
                    )
                )
            )
        );
    }
}
