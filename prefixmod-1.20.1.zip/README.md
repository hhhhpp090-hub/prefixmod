# Prefix Mod (Forge 1.20.1)

Мод для Minecraft Forge 1.20.1, который добавляет префиксы игрокам (`Admin`, `Ukraine`, `Russia`).

## Возможности
- Префиксы видны в TAB и над головой игрока
- В чате префиксы не показываются
- Доступные команды:
  - `/prefix preset <игрок> Admin`
  - `/prefix preset <игрок> Ukraine`
  - `/prefix preset <игрок> Russia`

## Установка
1. Соберите проект:
   ```
   ./gradlew build
   ```
2. Готовый `.jar` будет в `build/libs/`.
3. Переместите его в папку `mods/` клиента или сервера Forge 1.20.1.

## Лицензия
MIT
